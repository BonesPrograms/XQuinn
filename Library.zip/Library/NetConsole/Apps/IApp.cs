#if IAPP_BUILD
using System.Reflection;
using XQuinn.IO.Finders;
using System.Diagnostics;
using XQuinn.Extensions;
using XQuinn.Reflection;
using System.Collections.Concurrent;
using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;


namespace XQuinn.NetConsole.Apps
{
    /// <summary>
    /// This class represents a type that serves as a complete application for use in Console.
    /// </summary>
    internal interface IApp
    {

        static Dictionary<string, Type> IApps()
        {
            Dictionary<string, Type> iapps = new(StringComparer.OrdinalIgnoreCase);
            Assembly assembly = Assembly.Load("XQuinn");
            Type[] types = assembly.GetTypes();
            foreach (Type type in types)
            {
                if (!type.IsInterface && type.IsAssignableTo(typeof(IApp)))
                    iapps[type.Name] = type;
            }
            return iapps;
        }

        internal static void RunApp(string[] args)
        {
            if (args.Length == 1)
            {
                if (!IApps().TryGetValue(args[0], out Type? apptype))
                    return;
                try
                {
                    _ = Console.WindowHeight;
                }
                catch (IOException)
                {
                    throw new IOException("Cannot run console app types outside of console apps.");
                }
                IApp iapp = (IApp)Activator.CreateInstance(apptype!, true)!;
                iapp.Run();
                Console.ReadLine();
                Environment.Exit(0);
            }
        }


        // static string Filter(Type type)
        // {
        //     string name;
        //     if (type.Name.IndexOf("__") is int num && num != -1)
        //         name = type.Name[(num + "__".Length)..];
        //     else
        //         name = type.Name;
        //     return name;
        // }

        // static string[] Names()
        // {
        //     string[] arr = new string[Apps.Length];
        //     int i = 0;
        //     const string gap = "__"; //file types have messed up strings with double underscores preceding just before the actual type name
        //     foreach (string name in Apps.Select(x => x.Name))
        //     {
        //         if (name.IndexOf(gap) is int num && num != -1) //fancy contains
        //             arr[i] = name[(num + gap.Length)..]; //substring
        //         else
        //             arr[i] = name;
        //         i++;
        //         if (i == Apps.Length)
        //             break;
        //     }
        //     return arr;
        // }
        // Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
        // return assemblies.SelectMany(x => x.GetTypes()).Where(x => x.IsAssignableFrom(typeof(IApp))).ToImmutableDictionary(k => k.Name, v => v);
        //only BCL has IApps first of all, plus if BCL isnt executing, then its probably not a program that needs IApps since they only work in console

        public abstract void Run(); //Every IApp has a static Run() method, similar to a Main() method, a Run() takes no parameters and should require 0 prior setup.
                                    //these used to be static but we downgraded the system to support c9

    }                                       //IApps are ready to go and Run ecapsulates the entirety of their program's lifecycle



    sealed class ResourcesReplacer : IApp
    {
        static readonly string GameResourcesFolder = Path.Combine(VietnamWarSource.s_path, "Vietnam War_Data");
        static readonly string BackupResourcesFolder = Path.Combine(VietnamWarModLab.s_path, @"ResourcesGetter\BackupResources");
        static readonly string ModResourcesFolder = Path.Combine(VietnamWarModLab.s_path, @"ResourcesGetter\ModResources");
        static readonly Dictionary<string, string> ModResources = Directory.GetFiles(ModResourcesFolder).Select(file => (Name: Path.GetFileName(file), Path: file)).ToDictionary(key => key.Name, value => value.Path);
        static readonly Dictionary<string, string> GameResources = GetResources(GameResourcesFolder);
        static readonly string[] Options = { "BACKUP", "RESTORE FROM BACKUP", "INSTALL" };

        ResourcesReplacer()
        {

        }
        public void Run()
        {
            string? option = ConsoleTools.Choices(Options, "This program is for backing up Vietnam War assets and installing mod assets in their place.");
            if (option == null)
                return;
            if (option == Options[0])
            {
                if (Backup() == false)
                    Console.WriteLine("Already backed up!");
            }
            else if (option == Options[1])
            {
                Console.WriteLine("Restoring from backup...");
                Restore();
            }
            else if (option == Options[2])
            {
                Backup();
                Console.WriteLine("Installing...");
                Copy(ModResources, key => GameResources[key]);
            }
            Console.ReadLine();
        }

        public static void Restore()
        {
            if (!Directory.EnumerateFiles(BackupResourcesFolder).Any())
                throw new FileNotFoundException("Backup resources folder is empty.");
            var backups = GetResources(BackupResourcesFolder);
            Copy(backups, key => Path.Combine(GameResourcesFolder, key));
        }

        static bool Backup()
        {
            if (!Directory.EnumerateFiles(BackupResourcesFolder).Any())
            {
                Console.WriteLine("Backing up...");
                Copy(GameResources, key => Path.Combine(BackupResourcesFolder, key));
                return true;
            }
            return false;

        }

        //here, dictionary obj is the resources you are copying from
        //expr is a func that creates the copy target
        //typically it is going to be a Path.Combine with your target folder path + the key of the current object selected in the dictionary
        //(which will be a filename key w/o a path)
        static void Copy(Dictionary<string, string> obj, Func<string, string> expr)
        {
            obj.ForEach(x =>
            {
                string copyTo = expr(x.Key);
                Console.WriteLine($"Copying {x.Key} from {x.Value} to {copyTo}!");
                File.Copy(x.Value, copyTo, true);
            });
        }
        static Dictionary<string, string> GetResources(string path)
        {
            string[] names = ModResources.Keys.ToArray();
            Dictionary<string, string> resources = new(names.Length);
            foreach (var file in Directory.EnumerateFiles(path, "*.assets", SearchOption.TopDirectoryOnly))
            {
                string name = Path.GetFileName(file);
                if (names.Contains(name))
                {
                    resources[name] = file;
                }
            }
            return resources;
        }
    }

    sealed class PluginMaker : IApp
    {
        PluginMaker()
        {

        }
        static readonly string[] Insertions =
        {
      $"    <Reference Include=\"{InteropAssembly}\"/>",
      $"    <Reference Include=\"{Il2cppmscorlib}\"/>",
      $"    <Reference Include=\"{CoreModule}\"/>",
    };
        static readonly string ModsRoot = VietnamWarModLab.s_path;
        const string CoreModule = @"../interop\UnityEngine.CoreModule.dll";
        const string Il2cppmscorlib = @"../interop\Il2Cppmscorlib.dll";
        const string InteropAssembly = @"../interop\Assembly-CSharp.dll";

        public void Run()
        {
            Console.WriteLine("Enter the name of your plugin!");

            PluginMaker maker = new();
            maker.Make();
        }
        public void Make()
        {
            string pluginName = EnterName();
            Console.WriteLine($"Are you sure you want the name of your plugin to be {pluginName}?");
            Console.WriteLine("Press ENTER for yes, press any other key to change the name.");
            if (Console.ReadKey().Key != ConsoleKey.Enter)
            {
                Console.WriteLine("Enter a new name:");
                Make();
            }
            else
                CreateDirectory(pluginName);
        }

        void CreateDirectory(string name)
        {
            string pluginPath = Path.Combine(ModsRoot, name!);
            Directory.CreateDirectory(pluginPath);
            CreateProject(name, pluginPath);
            AddInteropReference(name, pluginPath);
            Console.WriteLine($"{name} created in {pluginPath}");
        }

        static void AddInteropReference(string name, string path)
        {
            string csproj = $@"{path}\{name}.csproj"; //could use directory.getfile here
            List<string> text = GetAndModifyText(csproj, name);
            using (StreamWriter writer = new(csproj))
            {
                foreach (var txt in text)
                    writer.WriteLine(txt);
            }
        }

        static List<string> GetAndModifyText(string csproj, string name)
        {
            List<string> text = File.ReadAllLines(csproj).ToList();
            int spot = text.IndexOf("  </ItemGroup>");
            foreach (var insert in Insertions)
                text.Insert(spot, insert);
            int nextspot = text.IndexOf("    <Product>My first plugin</Product>");
            string newstring = text[nextspot].Replace("My first plugin", name);
            text[nextspot] = newstring;
            return text;
        }



        void CreateProject(string name, string path)
        {
            ProcessStartInfo create = new()
            {
                FileName = "dotnet",
                Arguments = $"new bep6plugin_unity_il2cpp -n \"{name}\" -o \"{path}\"",
                UseShellExecute = false,
                RedirectStandardInput = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            };
            using (Process? process = Process.Start(create))
            {
                if (process != null)
                {
                    string output = process.StandardOutput.ReadToEnd();
                    string err = process.StandardError.ReadToEnd();
                    process.WaitForExit();
                    int code = process.ExitCode;
                    if (code != 0)
                    {
                        Console.WriteLine(output);
                        Console.WriteLine(err);
                        Console.ReadLine();
                    }
                }
                else
                {
                    Console.WriteLine("Process is null");
                    Console.ReadLine();
                }
            }
        }

        public static string EnterName()
        {
            bool invalid = true;
            string? plugin = string.Empty;
            while (invalid)
            {
                plugin = Console.ReadLine();
                invalid = string.IsNullOrWhiteSpace(plugin);
            }
            return plugin!;
        }
    }


    sealed class InteropDLLGetter : IApp //The idea with this is that if i get a new pc, i dont need to update all my project references
    {

        InteropDLLGetter()
        {

        }
        static readonly string Source = Path.Combine(VietnamWarSource.s_path, @"BepInEx\interop");
        static readonly string CopyTo = Path.Combine(VietnamWarModLab.s_path, "interop");
        static readonly string[] Assemblies = { "UnityEngine.CoreModule.dll", "Il2Cppmscorlib.dll", "Assembly-CSharp.dll" };

        public void Run()
        {
            foreach (var assembly in Assemblies)
            {
                Console.WriteLine($"Copying {assembly}");
                File.Copy(Path.Combine(Source, assembly), Path.Combine(CopyTo, assembly), true);
            }
        }
    }
}
#endif