#if NET6_0_OR_GREATER
using System.Reflection;
using XQuinn.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Loader;
using System;
using System.IO;


namespace XQuinn.Runtime
{

    // public interface IDynamicCleanup
    // {
    //     public abstract static void Shutdown(); 
    // }

    /// <summary>
    /// Invokes methods from a specific type in a dynamically loaded assembly. Only supports static methods with primitive, enum or string parameters. No in, outs or refs.
    /// Gets declared-only members, and does not support overloaded methods.
    /// </summary>
    /// <summary>
    /// Only supports single-file assemblies. Loads an assembly into the runtime and dynamically reloads it if it detects any updates to the file.
    /// </summary>
    /// 
    public sealed class DynamicNavigator : IDisposable
    {

        sealed class DLLBox : AssemblyLoadContext
        {
            public DLLBox() : base(isCollectible: true)
            {

            }
        }

        readonly NavigationFeed _monitor = new(true);
        public Func<Type, string?> BookDelegate = x => TypeRegister.GetCompatibleName(x, false);
        public string? DefaultLoadedTypeName;
        /// <summary>
        /// If changing DLLPath, call Reload.
        /// </summary>
        public string DLLPath;
        DLLBox? _box;
        Assembly? _assembly;

        /// <summary>
        /// If you change this, you most certainly will want to call reload afterwards.
        /// </summary>
        DateTime _lastwrite;

        DynamicNavigator(string path, Func<Type, string?>? bookDelegate) //DynamicReloader exists purely as a base class for DynamicInvoker. It is not intended for anyone else to inherit from.
        {
            if (bookDelegate != null)
                BookDelegate = bookDelegate;
            DLLPath = path;
        }

        public static DynamicNavigator New(string dllpath, Func<Type, string?> bookDelegate)
        {
            if (!File.Exists(dllpath)) throw new FileNotFoundException(dllpath);
            if (Path.GetExtension(dllpath) != ".dll") throw new ArgumentException("only .dll is supported by DynamicReloader");
            DynamicNavigator invoker = new(dllpath, bookDelegate);
            invoker.Reload();
            return invoker;
        }
        public void Reload()
        {
            WeakReference? monitor = Unload();
            // if (monitor != null)
            //     Collect(monitor);
            Load();
            //   Module[] modules = LoadedAssembly!.GetModules();
            //  if (modules.Length > 1) throw new NotSupportedException("Only single file assemblies are supported.");
            _monitor._core.LocalCache = TypeBook.New(_assembly!.ManifestModule.GetTypes(), BookDelegate);
            if (DefaultLoadedTypeName != null) _monitor._core.LoadTypeStatic(DefaultLoadedTypeName);
            _lastwrite = File.GetLastWriteTime(DLLPath);
        }

        public void Dispose()
        {
            Unload();
            GC.SuppressFinalize(this);
        }



        [MethodImpl(MethodImplOptions.NoInlining)]
        void Load()
        {
            _box = new DLLBox();
            using FileStream stream = File.OpenRead(DLLPath);
            _assembly = _box.LoadFromStream(stream);
        }
        [MethodImpl(MethodImplOptions.NoInlining)]
        WeakReference? Unload()
        {
            if (_box == null) return null;
            _monitor._core.Clear();
            NavigatorCore.FlushStaticCache();
            _assembly = null;
            WeakReference monitor = new(_box, trackResurrection: true);
            _box?.Unload();
            _box = null;
            return monitor;
        }

        public string Interface(string invocation)
        {
            if (CheckForReload())
                Reload();
            return _monitor.SafeInterface(invocation);
        }

        //This is the dynamic part
        //Whenever you try to get or invoke a method it will check if the assembly has been recompiled
        //and will reload its manifest module if so
        bool CheckForReload()
        {
            DateTime write = File.GetLastWriteTime(DLLPath);
            if (write != _lastwrite) { Reload(); return true; }
            else return false;
        }

    }
}
//Usage warnings:
//If you are invoking one of your reflected methods via dynamic invoker, your reflected methods should avoid the following behaviors:

//Do not create references to your own user defined classes in objects who's types are from outside of your assembly
//Do not subscribe to any events outside of your assembly
//Do not start background threads or tasks

//If your type provides a static parameterless method named Shutdown, it will be called on reload/unload, which you can use to easily clean up any objects
//you've made outside of your assembly before it is reloaded.
// // The plugin must use this to stop threads, unsubscribe from events, and remove references to objects from their assembly

//You are safe to create, and leave behind, new objects who's types are *not* from your assembly - your goal should be to not leave a trace that your assembly was in the runtime at all.

//If you mess up and there is a trace left over, you will likely experience a memory leak. Currently I have no way of detecting these myself.

//Final Warning: If you create multiple instances of DynamicInvoker that point to the same assembly, you will bloat your memory like crazy
//You should only have one dynamic invoker per assembly loaded
#endif