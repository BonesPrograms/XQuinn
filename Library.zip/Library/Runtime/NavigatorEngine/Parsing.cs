using System.Reflection;
using XQuinn.Extensions;
using XQuinn.LangInterp.SyntaxTree;
using System;
using System.Collections;
using System.Diagnostics.CodeAnalysis;
using HarmonyLib;

namespace XQuinn.Runtime.NavigatorEngine
{
    sealed class Parser : CoreObject
    {
        Invoker _invoker => _core._invoker;
        public Parser(NavigatorCore navig) : base(navig)
        {
        }

        /// <summary>
        /// Convert a method AST object to actual parameters by matching it to a MethodInfo's parameter array.
        /// </summary>
        public object?[] ParseParameters(ParameterInfo[] parameters, MethodString method)
        {
            int inputAmount = method.Params.Count;
            int reqAmount = parameters.Length;
            int lastparam = reqAmount - 1;
            if (reqAmount == 0)
                return inputAmount == 0 ? Array.Empty<object>() : throw new TargetParameterCountException($"input param count: {method.Params.Count} required count: {parameters.Length} method name {method.StringID}");
            object?[] args = new object[parameters.Length];
            if (method.Params.Count != reqAmount)
                UnequalParamCount(inputAmount, reqAmount, parameters, args, method, lastparam);
            else if (parameters[lastparam].IsDefined(typeof(ParamArrayAttribute)))
                ParamsArray(lastparam, parameters, args, method);
            else
                for (int i = 0; i < parameters.Length; i++)
                    args[i] = ParameterToObject(method.Params[i], parameters[i].ParameterType);
            return args;
        }

        void UnequalParamCount(int inputAmount, int reqAmount, ParameterInfo[] parameters, object?[] args, MethodString method, int lastparam)
        {
            if (inputAmount < reqAmount)
            {
                for (int i = inputAmount; i < reqAmount; i++)
                {
                    ParameterInfo parameter = parameters[i];
                    if (parameter.HasDefaultValue)
                        args[i] = parameter.DefaultValue;
                    else if (parameter.IsDefined(typeof(ParamArrayAttribute)))
                    {
                        Type elementType = parameters[i].ParameterType.GetElementType() ?? throw new ArgumentNullException();
                        args[i] = Array.CreateInstance(elementType, 0);
                    }
                    else
                        throw new TargetParameterCountException($"Parameter {parameter} does not have a default value. Input param count {inputAmount} Required count {reqAmount} method name {method.StringID}");
                }
                for (int i = 0; i < inputAmount; i++)
                    args[i] = ParameterToObject(method.Params[i], parameters[i].ParameterType);
            }
            else if (lastparam >= 0 && parameters[lastparam].IsDefined(typeof(ParamArrayAttribute)))
            {
                ParamsArray(lastparam, parameters, args, method);
            }
            else
                throw new TargetParameterCountException($"input param count: {method.Params.Count} required count: {parameters.Length} method name {method.Name}");
        }

        //Notes about
        void ParamsArray(int lastparam, ParameterInfo[] parameters, object?[] args, MethodString method)
        {
            for (int i = 0; i < lastparam; i++)
                args[i] = ParameterToObject(method.Params[i], parameters[i].ParameterType);
            Type elementType = parameters[lastparam].ParameterType.GetElementType() ?? throw new ArgumentNullException();
            object? defaultValue = elementType.GetDefaultValue();
            if (method.Params.Count == parameters.Length)
            {
                ParameterString parameter = method.Params[lastparam];
                if (parameter is ValueString val && (val.Argument.EqualsCaseless("null") || val.Argument.EqualsCaseless("default")))
                    args[lastparam] = null; //we do this because ParameterToObject pases vs elementType rather than array type. If elementType is a struct, it will fail to parse null,
                else                        //so for single-arguments that are explicitly null or default, there is a special case where we check early. more info on why below.
                {
                    object? arg = ParameterToObject(parameter, elementType);
                    if (!arg?.GetType().IsArray ?? true) //list && list.GetType() == actualParameters[lastparam].ParameterType) //i dont bother checking conversions most of the time runtime does it for me
                    {
                        Array singleArgArray = Array.CreateInstance(elementType, 1);
                        if (arg != null && !arg.Equals(defaultValue))
                            singleArgArray.SetValue(arg, 0);
                        arg = singleArgArray;
                    }
                    args[lastparam] = arg;
                }
            }
            else
            {
                Array paramsArray = Array.CreateInstance(elementType, method.Params.Count - lastparam); //assign array type via reflection becuase object[] wont work for params keyword
                for (int i = lastparam; i < method.Params.Count; i++)
                {
                    object? arg = ParameterToObject(method.Params[i], elementType);
                    if (arg != null && !arg.Equals(defaultValue))
                        paramsArray.SetValue(arg, i - lastparam); //null anyways so we skip setvalue if the result is null
                }
                args[lastparam] = paramsArray;
            }
        }



        //so this is secure
        //if you directly assign null/default as a single arg (ValueString), then we return the array as null
        //otherwise if you return null from a method field or property, it becomes a singleargarray with a null element
        //otherwise if you provide an array, we assign it
        //otherwise if you assign a single value, we add it to a singleargarray
        //so if you want to directly assign "null" and have a singleargarray come out - you cant, you need to precreate an array of size one with a single "null" element
        //i explain further below why this is correct and in line with C#

        //Notes:
        //If you send 'null' as your single argument to a 'params' array, I have a choice between creating an array of size 1 with a null value at index 0,
        //or I have the choice of treating the entire argument as 'null' and returning 'null' for the params array.
        //Experimentation reveals that if you send 'null' as a single argument to a params array in C#, the params array is assigned null
        //However, if you send more than one 'null' argument to a params array, it will create an array of that size with it's elements null
        //So we match that decision here as well.
        //In essence if you want to have a 'params array' compile as a size 1 array with a single null element, you actually need to create your own array
        //and pass it instead rather than utilizing the 'params' feature.
        //Furthermore, if a method, property or field returns null, that value is turned into a single arg array in standard C#. So only explicit "null" or "default" will assign
        //null to the array parameter.
        internal object? ParameterToObject(ParameterString arg, Type paramType)
        {
            object? obj = arg switch
            {
                FieldString field => _invoker.InvokeFieldOrProperty(field),
                MethodString method => _invoker.InvokeMethod(method),
                ValueString value => ParseValue(value, paramType),
                _ => throw new NotSupportedException()
            };
            //   Reflector.InvalidCast(paramType, obj);
            Reflector.NotNullable(paramType, obj);
            return obj;

        }
        internal object? ParseValue(ValueString value, Type paramType) //need half and int128 support
        {
            string strng = value.Argument;
            if (strng.EqualsCaseless("this"))
            {
                if (_object == null)
                    throw new InvalidOperationException("Cannot pass this as parameter, instance is null.");
                // if (!paramType.IsAssignableFrom(_instanceType))
                //     throw new InvalidCastException($"Current instance is a {_instanceType} and does not cast to parameter type {paramType}");
                return _object;
            }
            if (_variables?.TryGetValue(strng, out VariableBinding? variable) ?? false)
            {
                // if (!paramType.IsAssignableFrom(variable.ObjectType))
                //     throw new InvalidCastException($"Instance index object with key {strng} is a {variable.ObjectType} and does not cast to parameter type {paramType}");
                return variable.Object;
            }
            if (_fields.TryGetValue(strng, out FieldInfo? field))
            {
                // object? val = field.GetValue(_instance);
                // Type t = val == null ? field.FieldType : val.GetType();
                // if(!paramType.IsAssignableFrom(t))
                return field.GetValue(_object);
            }
            if (_props.TryGetValue(strng, out PropertyInfo? prop))
            {
                return prop.GetValue(_object, NavigatorCore.Flag, null, null, null);
            }
            return value.Parse(paramType);
        }
    }
}
